<?php
$baseUrl = '../';

//Al cancelar el pago, debe devolver a la página de detallesSorteo del sorteo donde estaba, por lo que tiene que recibir la idSorteo correspondiente
?>

<h2>Pedido cancelado</h2>
<p>El pedido fue cancelado, vuelve a la página de compra dando clic <a href="<?= $baseUrl ?>/detallesSorteo.php">aquí</a></p>